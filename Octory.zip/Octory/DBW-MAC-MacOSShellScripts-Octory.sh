#!/bin/bash
#==============================================================================
# Script Name: Octory Script
# Description: Provides a script to download and launch Octory during Setup of macOS in order to show a nice UX during Installation of Standard Software.
#
# Author: Leon Kesko
# Created: 01.06.2025
#
# Changelog:
# - 01.06.2025: Initial Creation (by Leon)
# - 01.06.2025: Added detailed Comments and Logging (by Leon)
# - 10.06.2025: Removed the Rosetta-Routone (by Leon)
#
#==============================================================================  


# User-defined variables
weburl="https://github.com/lkesko/Octory_pub/raw/refs/heads/main/Octory.zip"   # URL for Octory archive

# ---------------------------------------------------------------------
# SHA-256 Hash of the octory.zip file
# Check with: shasum -a 256 Octory.zip 
# ---------------------------------------------------------------------
expected_hash="81727dedb161e0a22c436d075943f9b809c3b2842a92f5e95737f8bc94dbff03"

# ---------------------------------------------------------------------
# Toggle: Company-Portal-Check (1 = active, 0 = deactivated (for testing))
# ---------------------------------------------------------------------
checkCompanyPortal=0


# Standard variables
targetdir="/Library/Application Support/Octory"                 # Installation directory
appname="Octory"                                                # Application name (for logs)
logandmetadir="/Library/Logs/Microsoft/IntuneScripts/Octory"    # Log file directory

# Generated variables
tempdir=$(mktemp -d)                                            # Temp directory
tempfile="$tempdir/octory.zip"                                  # Temp file
log="$logandmetadir/$appname.log"                               # Log file name
consoleuser=$(ls -l /dev/console | awk '{ print $3 }')          # Current user

#---------------------------------------------------------------------
# Logging directory
#---------------------------------------------------------------------
if [ -d "$logandmetadir" ]; then
    echo "$(date) | Log directory already exists – $logandmetadir"
else
    echo "$(date) | Creating log directory – $logandmetadir"
    mkdir -p "$logandmetadir"
fi

#---------------------------------------------------------------------
# Helper: wait until user desktop (Dock) is ready
#---------------------------------------------------------------------
waitForDesktop() {
    until pgrep -xf "/System/Library/CoreServices/Dock.app/Contents/MacOS/Dock" >/dev/null; do
        echo "$(date) |  + Dock not running, waiting..."
        sleep 5
    done
    echo "$(date) | Desktop is here, let's carry on"
}

#---------------------------------------------------------------------
# Helper: cleanup temp + install dirs (optional – currently disabled)
#---------------------------------------------------------------------
cleanup() {
    cd "$HOME"

    if [ -d "$tempdir" ]; then
        echo "$(date) | Cleanup – Removing temp directory [$tempdir]"
        rm -rf "$tempdir"
    fi

    if [ -d "$targetdir" ]; then
        echo "$(date) | Cleanup – Removing target directory [$targetdir]"
        rm -rf "$targetdir"
    fi

    # Remove octo-notifier, if needed
    rm -rf /usr/local/bin/octo-notifier
}

#---------------------------------------------------------------------
# Start logging
#---------------------------------------------------------------------
exec &> >(tee -a "$log")

echo ""
echo "##############################################################"
echo "# $(date) | Starting install of $appname"
echo "##############################################################"
echo ""

#---------------------------------------------------------------------
# Skip when Company Portal already launched
#---------------------------------------------------------------------
if [[ "$checkCompanyPortal" -eq 1 ]]; then
    if [[ -f "/Users/$consoleuser/Library/Preferences/com.microsoft.CompanyPortalMac.plist" ]]; then
        echo "$(date) | Skipping Octory launch for user [$consoleuser] – Company Portal already launched."
        exit 0
    fi
else
    echo "$(date) | Company-Portal-Prüfung deaktiviert (Testmodus) – Skript läuft weiter."
fi

#---------------------------------------------------------------------
# Download, unzip and move application and resources
#---------------------------------------------------------------------
echo "$(date) | Downloading [$appname] from [$weburl]"
curl -f -s --connect-timeout 30 --retry 5 --retry-delay 60 -L -o "$tempfile" "$weburl"
if [[ $? -ne 0 ]]; then
    echo "$(date) | ERROR: Download failed – aborting."
    cleanup
    exit 1
fi

# ---------------------------------------------------------------------
# Hash verification
# ---------------------------------------------------------------------
echo "$(date) | Verifying SHA-256 hash of downloaded file …"
actual_hash=$(shasum -a 256 "$tempfile" | awk '{print $1}')

if [[ "$actual_hash" == "$expected_hash" ]]; then
    echo "$(date) | Hash match ✅  ($actual_hash)"
else
    echo "$(date) | Hash mismatch"
    echo "$(date) | Expected: $expected_hash"
    echo "$(date) | Actual  : $actual_hash"
    echo "$(date) | Aborting Octory."
    cleanup
    exit 1
fi


# ---------------------------------------------------------------------
# Unzip the downloaded file and proceed if hash matches
# ---------------------------------------------------------------------

echo "$(date) | Unzipping binary and resource files"
unzip -q "$tempfile"

# Remove previous Octory files if they exist
if [ -d "$targetdir" ]; then
    echo "$(date) | Removing previous Octory files from [$targetdir]"
    rm -rf "$targetdir"
fi

# Install octo-notifier
sudo installer -pkg "$tempdir/Octory/Octory notifier.pkg" -target /
if [[ $? -eq 0 ]]; then
    echo "$(date) | octo-notifier successfully installed"
else
    echo "$(date) | octo-notifier installation failed"
fi

# Move files into correct location
echo "$(date) | Copying to /Library/Application Support/Octory"
mv Octory/ "/Library/Application Support/"
cd "/Library/Application Support/Octory"

# Ensure correct permissions are set
echo "$(date) | Setting permissions on [$targetdir]"
sudo chown -R root:wheel "$targetdir"
sudo chmod -R 755 "$targetdir"
sudo chmod 644 "$targetdir/onboarding.plist"

#---------------------------------------------------------------------
# Wait until Setup Assistant finished, then launch Octory
#---------------------------------------------------------------------
waitForDesktop

echo "$(date) | Launching Octory"
sudo Octory.app/Contents/MacOS/Octory -c onboarding.plist
if [[ $? -eq 0 ]]; then
    echo "$(date) | Octory successfully launched"
    #cleanup
    exit 0
else
    echo "$(date) | Octory failed to launch, retrying once"
    sleep 10
    sudo Octory.app/Contents/MacOS/Octory -c onboarding.plist
    if [[ $? -eq 0 ]]; then
        echo "$(date) | Octory successfully launched on 2nd attempt"
        #cleanup
        exit 0
    else
        echo "$(date) | Octory failed on 2nd launch"
        #cleanup
        exit 1
    fi
fi